var journal = new Vue({
  el: '#journal',
  data: {
    message: 'Your first entry'
  }
});
